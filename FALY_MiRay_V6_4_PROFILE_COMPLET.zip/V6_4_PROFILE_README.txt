FALY MiRay V6.4 — Profil utilisateur

Ajouts :
- Nom et prénom visibles en grand dans Profil.
- E-mail visible.
- Ville/localisation visible.
- Type de profil visible.
- Photo de profil visible.
- Bio facultative.
- Bouton Modifier.
- Modification du nom, ville, type de profil, bio.
- Photo envoyée via Cloudinary.
- Profil enregistré dans Firestore users/{uid}.
- Nom et photo synchronisés avec Firebase Authentication.
- Mon activité reste intégré dans Profil.

Important :
Les utilisateurs créés par e-mail doivent avoir un nom renseigné à l'inscription.
Si un ancien compte n'en possède pas, "Utilisateur MiRay" s'affiche jusqu'à modification du profil.
