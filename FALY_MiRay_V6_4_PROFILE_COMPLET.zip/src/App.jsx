import React, { useEffect, useState } from "react";
import {
  createUserWithEmailAndPassword,
  getRedirectResult,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInAnonymously,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile
} from "firebase/auth";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { Eye, LogIn } from "lucide-react";
import FalyMirayUserApp from "./FalyMirayUserApp.jsx";
import Landing from "./Landing.jsx";
import CreatorStudio from "./CreatorStudio.jsx";
import AdminDashboard from "./AdminDashboard.jsx";
import { auth, db, firebaseReady, googleProvider, firebaseConfigInUse } from "./firebase.js";

const C={navy:"#0D1321",navySoft:"#161F33",gold:"#D4AF37",white:"#FFFFFF",slate:"#6B7280"};

function Login({onPreview}) {
  const [mode,setMode]=useState("login");
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [confirmPassword,setConfirmPassword]=useState("");
  const [error,setError]=useState("");
  const [notice,setNotice]=useState("");
  const [busy,setBusy]=useState(false);

  const friendlyError=(e)=>{
    const code=e?.code || "";
    if(code==="auth/email-already-in-use") return "Cette adresse e-mail possède déjà un compte.";
    if(code==="auth/invalid-email") return "Adresse e-mail invalide.";
    if(code==="auth/weak-password") return "Le mot de passe doit contenir au moins 6 caractères.";
    if(code==="auth/invalid-credential") return "E-mail ou mot de passe incorrect.";
    if(code==="auth/user-disabled") return "Ce compte a été désactivé.";
    if(code==="auth/too-many-requests") return "Trop de tentatives. Réessayez un peu plus tard.";
    if(code==="auth/operation-not-allowed") return "La connexion par e-mail/mot de passe n'est pas encore activée dans Firebase Authentication.";
    if(code==="auth/api-key-not-valid") return "La clé API Firebase du site est invalide. L'administrateur doit corriger la configuration Firebase.";
    return `${code || "auth/error"} — ${e?.message || "Une erreur est survenue."}`;
  };

  const submitEmail=async(e)=>{
    e?.preventDefault();
    if(!firebaseReady){setError("Clé API Firebase non configurée. Vérifiez le secret GitHub VITE_FIREBASE_API_KEY.");return;}
    setError(""); setNotice("");
    if(!email.trim() || !password){setError("Renseignez votre e-mail et votre mot de passe.");return;}
    if(mode==="register"){
      if(!name.trim()){setError("Renseignez votre nom.");return;}
      if(password.length<6){setError("Le mot de passe doit contenir au moins 6 caractères.");return;}
      if(password!==confirmPassword){setError("Les deux mots de passe ne correspondent pas.");return;}
    }
    setBusy(true);
    try{
      if(mode==="register"){
        const credential=await createUserWithEmailAndPassword(auth,email.trim(),password);
        await updateProfile(credential.user,{displayName:name.trim()});
        if(db){
          await setDoc(doc(db,"users",credential.user.uid),{
            uid:credential.user.uid,
            displayName:name.trim(),
            email:credential.user.email || email.trim(),
            photoURL:"",
            provider:"password",
            createdAt:serverTimestamp(),
            updatedAt:serverTimestamp()
          },{merge:true});
        }
      }else{
        await signInWithEmailAndPassword(auth,email.trim(),password);
      }
    }catch(e){
      console.error(e);
      setError(friendlyError(e));
    }finally{setBusy(false);}
  };

  const resetPassword=async()=>{
    setError(""); setNotice("");
    if(!email.trim()){setError("Entrez d'abord votre adresse e-mail.");return;}
    setBusy(true);
    try{
      await sendPasswordResetEmail(auth,email.trim());
      setNotice("Un e-mail de réinitialisation a été envoyé.");
    }catch(e){setError(friendlyError(e));}
    finally{setBusy(false);}
  };

  const google=async()=>{
    if(!firebaseReady){setError("Clé API Firebase non configurée. Vérifiez le secret GitHub VITE_FIREBASE_API_KEY.");return;}
    setError(""); setNotice(""); setBusy(true);
    try{
      await signInWithPopup(auth, googleProvider);
    }catch(e){
      console.error(e);
      setError(friendlyError(e));
    }finally{setBusy(false);}
  };

  const guest=async()=>{
    if(!firebaseReady) return onPreview();
    try{await signInAnonymously(auth);}catch(e){console.warn(e);onPreview();}
  };

  return <div className="min-h-screen flex items-center justify-center p-5" style={{background:C.navy}}>
    <div className="w-full max-w-md rounded-3xl p-6" style={{background:C.navySoft,border:`1px solid ${C.gold}55`,color:C.white}}>
      <img src="/faly-miray-logo.png" alt="FALY MiRay" className="w-40 mx-auto rounded-2xl"/>
      <h1 className="text-2xl font-bold mt-4 text-center">FALY <span style={{color:C.gold}}>MiRay</span></h1>
      <p className="text-sm text-center mt-2" style={{color:C.slate}}>Un seul compte pour découvrir, acheter, publier, vendre et trouver des opportunités.</p>

      <div className="grid grid-cols-2 gap-2 mt-5 p-1 rounded-xl" style={{background:"#0b1020"}}>
        <button onClick={()=>{setMode("login");setError("");setNotice("");}} className="rounded-lg py-2 text-sm font-semibold"
          style={{background:mode==="login"?C.gold:"transparent",color:mode==="login"?C.navy:C.white}}>Connexion</button>
        <button onClick={()=>{setMode("register");setError("");setNotice("");}} className="rounded-lg py-2 text-sm font-semibold"
          style={{background:mode==="register"?C.gold:"transparent",color:mode==="register"?C.navy:C.white}}>Inscription</button>
      </div>

      <form onSubmit={submitEmail} className="mt-4 space-y-3">
        {mode==="register" && <input value={name} onChange={e=>setName(e.target.value)} placeholder="Nom et prénom"
          className="w-full rounded-xl px-4 py-3 text-sm outline-none" style={{background:"#fff",color:C.navy}}/>}
        <input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="Adresse e-mail"
          className="w-full rounded-xl px-4 py-3 text-sm outline-none" style={{background:"#fff",color:C.navy}}/>
        <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Mot de passe"
          className="w-full rounded-xl px-4 py-3 text-sm outline-none" style={{background:"#fff",color:C.navy}}/>
        {mode==="register" && <input value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} type="password" placeholder="Confirmer le mot de passe"
          className="w-full rounded-xl px-4 py-3 text-sm outline-none" style={{background:"#fff",color:C.navy}}/>}

        <button disabled={busy} type="submit" className="w-full rounded-xl py-3 font-semibold"
          style={{background:C.gold,color:C.navy,opacity:busy?.7:1}}>
          {busy?"Veuillez patienter…":mode==="register"?"Créer mon compte":"Se connecter"}
        </button>
      </form>

      {mode==="login" && <button onClick={resetPassword} disabled={busy} className="w-full mt-2 text-xs underline" style={{color:"#c3cada"}}>
        Mot de passe oublié ?
      </button>}

      <div className="flex items-center gap-3 my-4">
        <div className="h-px flex-1" style={{background:"#2b354b"}}/>
        <span className="text-[11px]" style={{color:C.slate}}>ou</span>
        <div className="h-px flex-1" style={{background:"#2b354b"}}/>
      </div>

      <button onClick={google} disabled={busy} className="w-full rounded-xl py-3 font-medium flex items-center justify-center gap-2"
        style={{border:"1px solid #33405a",color:C.white}}>
        <LogIn size={18}/> Continuer avec Google <span className="text-[10px]" style={{color:C.slate}}>(optionnel)</span>
      </button>

      <button onClick={guest} className="w-full mt-3 rounded-xl py-3 font-medium flex items-center justify-center gap-2"
        style={{border:"1px solid #27324a",color:C.white}}>
        <Eye size={18}/> Mode découverte
      </button>

      {notice && <div className="mt-3 rounded-xl p-3 text-xs" style={{background:"#123525",color:"#b9f6cf"}}>{notice}</div>}
      {error && <div className="mt-3 rounded-xl p-3 text-[11px] bg-red-950/40 text-red-200 break-words">{error}</div>}
    </div>
  </div>;
}
export default function App(){
  const [user,setUser]=useState(undefined);
  const [admin,setAdmin]=useState(false);
  const [preview,setPreview]=useState(false);
  const [pastLanding,setPastLanding]=useState(false);
  const [studio,setStudio]=useState(false);

  useEffect(()=>{
    if(!firebaseReady){setUser(null);return;}
    getRedirectResult(auth).catch(console.warn);
    return onAuthStateChanged(auth,async u=>{
      setUser(u); setStudio(false);
      if(!u){setAdmin(false);return;}
      try{
        if(!u.isAnonymous){
          await setDoc(doc(db,"users",u.uid),{
            uid:u.uid,displayName:u.displayName||"",email:u.email||"",
            photoURL:u.photoURL||"",updatedAt:serverTimestamp()
          },{merge:true});
        }
        const adminSnap=await getDoc(doc(db,"admins",u.uid));
        setAdmin(adminSnap.exists());
      }catch(e){console.warn("Initialisation profil/admin:",e);setAdmin(false);}
    });
  },[]);

  if(user===undefined) return <div className="min-h-screen grid place-items-center" style={{background:C.navy,color:C.white}}>Chargement…</div>;
  if(!user&&!preview&&!pastLanding) return <Landing onEnter={()=>setPastLanding(true)}/>;
  if(!user&&!preview) return <Login onPreview={()=>setPreview(true)}/>;
  if(admin) return <AdminDashboard user={user}/>;
  if(studio && user && !user.isAnonymous) return <CreatorStudio onBack={()=>setStudio(false)}/>;

  return <div className="relative w-full min-h-[100dvh]">
    <FalyMirayUserApp onOpenActivity={user && !user.isAnonymous ? ()=>setStudio(true) : undefined}/>
  </div>;
}
