// FALY MiRay V6 — configuration publique côté navigateur.
// La configuration Firebase Web et le preset Cloudinary unsigned ne sont pas des secrets.
export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyAxk1b3pq5vUCjJky0cASssktr3Cu7C6G8",
  authDomain: "faly-miray.firebaseapp.com",
  projectId: "faly-miray",
  storageBucket: "faly-miray.firebasestorage.app",
  messagingSenderId: "952480755434",
  appId: "1:952480755434:web:374ab34357741b45113193",
  measurementId: "G-M5L5YXV4KJ",
};

export const CLOUDINARY_CONFIG = {
  cloudName: "alfrtkxe",
  uploadPreset: "faly_miray_uploads",
  maxFileSizeMb: 5,
  allowedMimeTypes: ["image/jpeg", "image/png", "image/webp"],
};

export const APP_CONFIG = {
  hostingSiteId: "miray",
  projectId: "faly-miray",
  appName: "FALY MiRay",
};
