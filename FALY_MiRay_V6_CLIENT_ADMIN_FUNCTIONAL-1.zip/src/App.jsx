import React, { useEffect, useState } from "react";
import {
  browserPopupRedirectResolver,
  getRedirectResult,
  onAuthStateChanged,
  signInAnonymously,
  signInWithPopup,
  signInWithRedirect
} from "firebase/auth";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { BriefcaseBusiness, Eye, LogIn } from "lucide-react";
import FalyMirayUserApp from "./FalyMirayUserApp.jsx";
import Landing from "./Landing.jsx";
import CreatorStudio from "./CreatorStudio.jsx";
import AdminDashboard from "./AdminDashboard.jsx";
import { auth, db, firebaseReady, googleProvider } from "./firebase.js";

const C={navy:"#0D1321",navySoft:"#161F33",gold:"#D4AF37",white:"#FFFFFF",slate:"#6B7280"};

function Login({onPreview}) {
  const [error,setError]=useState("");
  const google=async()=>{
    if(!firebaseReady){setError("Configuration Firebase manquante.");return;}
    setError("");
    try{
      await signInWithPopup(auth,googleProvider,browserPopupRedirectResolver);
    }catch(e){
      console.error(e);
      if(["auth/popup-blocked","auth/cancelled-popup-request","auth/popup-closed-by-user"].includes(e.code)){
        await signInWithRedirect(auth,googleProvider);
      }else{
        setError(`${e.code || "auth/error"} — ${e.message || "Connexion Google impossible."}`);
      }
    }
  };
  const guest=async()=>{
    if(!firebaseReady) return onPreview();
    try{await signInAnonymously(auth);}catch(e){console.warn(e);onPreview();}
  };
  return <div className="min-h-screen flex items-center justify-center p-5" style={{background:C.navy}}>
    <div className="w-full max-w-sm rounded-3xl p-6" style={{background:C.navySoft,border:`1px solid ${C.gold}55`,color:C.white}}>
      <img src="/faly-miray-logo.png" alt="FALY MiRay" className="w-44 mx-auto rounded-2xl"/>
      <h1 className="text-2xl font-bold mt-5 text-center">FALY <span style={{color:C.gold}}>MiRay</span></h1>
      <p className="text-sm text-center mt-2" style={{color:C.slate}}>Découvrir, acheter, publier, vendre et trouver des opportunités avec un seul compte.</p>
      <button onClick={google} className="w-full mt-5 rounded-xl py-3 font-semibold flex items-center justify-center gap-2" style={{background:C.gold,color:C.navy}}><LogIn size={18}/> Continuer avec Google</button>
      <button onClick={guest} className="w-full mt-3 rounded-xl py-3 font-medium flex items-center justify-center gap-2" style={{border:"1px solid #27324a",color:C.white}}><Eye size={18}/> Mode découverte</button>
      {error && <div className="mt-3 rounded-xl p-3 text-[11px] bg-red-950/40 text-red-200 break-words">{error}</div>}
    </div>
  </div>;
}

export default function App(){
  const [user,setUser]=useState(undefined);
  const [admin,setAdmin]=useState(false);
  const [preview,setPreview]=useState(false);
  const [pastLanding,setPastLanding]=useState(false);
  const [studio,setStudio]=useState(false);

  useEffect(()=>{
    if(!firebaseReady){setUser(null);return;}
    getRedirectResult(auth).catch(console.warn);
    return onAuthStateChanged(auth,async u=>{
      setUser(u); setStudio(false);
      if(!u){setAdmin(false);return;}
      try{
        if(!u.isAnonymous){
          await setDoc(doc(db,"users",u.uid),{
            uid:u.uid,displayName:u.displayName||"",email:u.email||"",
            photoURL:u.photoURL||"",updatedAt:serverTimestamp()
          },{merge:true});
        }
        const adminSnap=await getDoc(doc(db,"admins",u.uid));
        setAdmin(adminSnap.exists());
      }catch(e){console.warn("Initialisation profil/admin:",e);setAdmin(false);}
    });
  },[]);

  if(user===undefined) return <div className="min-h-screen grid place-items-center" style={{background:C.navy,color:C.white}}>Chargement…</div>;
  if(!user&&!preview&&!pastLanding) return <Landing onEnter={()=>setPastLanding(true)}/>;
  if(!user&&!preview) return <Login onPreview={()=>setPreview(true)}/>;
  if(admin) return <AdminDashboard user={user}/>;
  if(studio && user && !user.isAnonymous) return <CreatorStudio onBack={()=>setStudio(false)}/>;

  return <div className="relative">
    <FalyMirayUserApp/>
    {user && !user.isAnonymous && <button onClick={()=>setStudio(true)}
      className="fixed z-50 right-4 bottom-4 rounded-full px-4 py-3 shadow-xl flex items-center gap-2 text-xs font-semibold"
      style={{background:C.gold,color:C.navy}}>
      <BriefcaseBusiness size={17}/> Mon activité
    </button>}
  </div>;
}
