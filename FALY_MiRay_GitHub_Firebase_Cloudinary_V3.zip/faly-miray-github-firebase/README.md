# FALY MiRay — GitHub + Firebase + Cloudinary V2

Version prête à déposer sur GitHub, basée sur le prototype V2 FALY MiRay.

## Architecture

- **Firebase Hosting** : hébergement du site
- **Firebase Authentication** : connexion Google / utilisateur
- **Cloud Firestore** : données de l'application
- **Cloudinary** : images (remplace Firebase Storage)
- **2 rôles seulement** : `user` et `admin`

Un utilisateur MiRay peut être client, entrepreneur, artiste, artisan, restaurateur, hôtelier, vendeur, promoteur ou simplement explorateur avec le même compte.

## Configuration déjà intégrée

La configuration Web Firebase fournie pour le projet `faly-miray` et le preset Cloudinary `faly_miray_uploads` sont centralisés dans :

`src/appConfig.js`

Le projet ne contient **aucun API Secret Cloudinary** ni aucune clé Firebase Admin.

### Cloudinary

- Upload preset : `faly_miray_uploads`
- Mode : `Unsigned`
- Formats contrôlés côté application : JPG, PNG, WEBP
- Taille contrôlée côté application : 5 Mo maximum
- Service d'upload : `src/services/cloudinary.js`

Dans **Profil**, une zone **Test photo Cloudinary** permet de vérifier immédiatement qu'un upload fonctionne après déploiement.

> Si le Cloud Name de votre compte diffère de celui détecté lors de la configuration, modifiez uniquement `cloudName` dans `src/appConfig.js`.

## GitHub

1. Décompressez le ZIP.
2. Ouvrez le dossier `faly-miray-github-firebase`.
3. Uploadez **le contenu de ce dossier** dans un dépôt GitHub `faly-miray`.
4. Ne créez pas de fichier contenant un `API Secret` Cloudinary.

## Test local

```bash
npm install
npm run dev
```

## Build

```bash
npm install
npm run build
```

Le dossier généré est `dist/`.

## Firebase Hosting

Le fichier `firebase.json` est déjà configuré pour une SPA Vite.

Après installation de Firebase CLI :

```bash
npm run build
firebase login
firebase use faly-miray
firebase deploy --only hosting
```

## Firebase à activer

### Authentication
Activez au minimum :
- Google
- Anonymous si vous gardez le mode découverte

### Firestore
Collections prévues :
- `users`
- `pages`
- `products`
- `services`
- `events`
- `opportunities`
- `conversations`
- `reviews`
- `favorites`
- `reports`

Firebase Storage n'est plus utilisé dans cette version.

## Admin

Le rôle administrateur doit être attribué avec un **Firebase Custom Claim** `admin: true`, jamais avec un champ modifiable par l'utilisateur dans Firestore.

## Important

Les données de démonstration (restaurants, hôtels, événements, actualités et messages simulés) restent présentes afin que l'interface soit immédiatement visible. La prochaine étape consiste à remplacer progressivement ces données par les collections Firestore réelles.
