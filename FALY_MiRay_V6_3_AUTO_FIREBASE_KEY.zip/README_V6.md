# FALY MiRay V6 — Client + Activité + Admin

## Ce qui fonctionne

### Compte utilisateur unique
- Connexion Google
- Mode découverte
- Interface client MiRay existante
- Cloudinary pour l'upload d'images
- Bouton **Mon activité**
- Création d'une page professionnelle
- Publication de produits
- Publication d'événements
- Publication d'opportunités
- Consultation et suppression de ses propres publications

### Administration
- Dashboard séparé
- Comptage utilisateurs / pages / produits
- Liste utilisateurs, pages, produits, événements, opportunités
- Validation / refus des pages et contenus
- Suppression par l'admin
- Droits basés sur une collection Firestore `admins`

## IMPORTANT — créer le premier admin

1. Connectez-vous une première fois avec le compte Google qui sera administrateur.
2. Dans Firebase Console > Authentication > Users, copiez son **UID**.
3. Dans Firestore, créez la collection `admins`.
4. Créez un document dont l'ID est exactement cet UID.
5. Le document peut contenir :
   - `email`: votre email
   - `active`: true

Au prochain chargement, ce compte ouvrira automatiquement l'interface Admin.

La collection `admins` ne peut pas être modifiée par l'application web.

## Firebase Authentication

Activez :
- Google
- Anonymous (facultatif, le mode découverte fonctionne également comme aperçu)

Domaines autorisés :
- `miray.web.app`
- `miray.firebaseapp.com`
- `faly-miray.web.app`
- `faly-miray.firebaseapp.com`

## Cloudinary

Déjà configuré :
- Cloud name : `alfrtkxe`
- Preset unsigned : `faly_miray_uploads`
- 5 Mo max côté application
- JPG / PNG / WEBP

## GitHub

Le secret requis reste :
`FIREBASE_SERVICE_ACCOUNT_FALY_MIRAY`

La clé privée n'est volontairement PAS incluse dans ce ZIP.

## Déploiement

Uploader le CONTENU du ZIP à la racine du dépôt GitHub.
Le workflow :
1. installe les dépendances
2. compile Vite
3. déploie les règles Firestore
4. déploie le site `miray` sur Firebase Hosting

URL :
- https://miray.web.app
- https://miray.firebaseapp.com
