FALY MiRay V6.1 — AUTH FIX

Corrections:
- Firebase Web config set to the exact values shown in Firebase Console.
- Optional VITE_FIREBASE_* overrides supported.
- Google sign-in uses the standard signInWithPopup(auth, provider).
- Runtime diagnostics show project/authDomain/key prefix if Auth fails.
- GitHub workflow deploys Hosting even if Firestore IAM rule deployment fails.

IMPORTANT:
If the site still shows auth/api-key-not-valid with key prefix AIzaSyAx…,
the ZIP is using the correct config and the API key itself must be checked in
Google Cloud Console > APIs & Services > Credentials. Verify the key exists
and is not restricted in a way that blocks Identity Toolkit / Firebase Auth.
