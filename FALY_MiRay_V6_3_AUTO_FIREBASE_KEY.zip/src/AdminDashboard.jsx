import React, { useEffect, useMemo, useState } from "react";
import {
  BadgeCheck, CalendarDays, Check, ChevronRight, LogOut, RefreshCw,
  ShieldCheck, ShoppingBag, Store, Trash2, Users, BriefcaseBusiness, X
} from "lucide-react";
import {
  collection, deleteDoc, doc, onSnapshot, serverTimestamp, updateDoc
} from "firebase/firestore";
import { signOut } from "firebase/auth";
import { auth, db } from "./firebase.js";

const C={navy:"#0D1321",navySoft:"#161F33",gold:"#D4AF37",slate:"#6B7280",ivory:"#F7F4EE",white:"#fff"};
const defs = {
  users: {label:"Utilisateurs", icon:Users},
  pages: {label:"Pages", icon:Store},
  products: {label:"Produits", icon:ShoppingBag},
  events: {label:"Événements", icon:CalendarDays},
  opportunities: {label:"Opportunités", icon:BriefcaseBusiness},
};

export default function AdminDashboard({ user }) {
  const [tab,setTab]=useState("pages");
  const [data,setData]=useState({users:[],pages:[],products:[],events:[],opportunities:[]});
  const [error,setError]=useState("");

  useEffect(()=>{
    if(!db) return;
    const unsubs=Object.keys(defs).map(name =>
      onSnapshot(collection(db,name),
        snap=>setData(prev=>({...prev,[name]:snap.docs.map(d=>({id:d.id,...d.data()}))})),
        err=>setError(err.message)
      )
    );
    return ()=>unsubs.forEach(u=>u());
  },[]);

  const pending = data.pages.filter(x=>x.status==="pending").length;
  const cards = [
    ["Utilisateurs",data.users.length,Users],
    ["Pages professionnelles",data.pages.length,Store],
    ["Produits",data.products.length,ShoppingBag],
    ["À valider",pending,BadgeCheck],
  ];

  const approve = async (item) => {
    await updateDoc(doc(db,tab,item.id), {status:"published", verified:true, reviewedAt:serverTimestamp(), reviewedBy:user.uid});
  };
  const reject = async (item) => {
    await updateDoc(doc(db,tab,item.id), {status:"rejected", verified:false, reviewedAt:serverTimestamp(), reviewedBy:user.uid});
  };
  const remove = async (item) => {
    if(!confirm("Supprimer définitivement cet élément ?")) return;
    await deleteDoc(doc(db,tab,item.id));
  };

  const Def=defs[tab]; const Icon=Def.icon;

  return <div className="min-h-screen" style={{background:C.ivory,color:C.navy,fontFamily:"Poppins, sans-serif"}}>
    <header className="sticky top-0 z-20" style={{background:C.navy,color:C.white}}>
      <div className="max-w-7xl mx-auto p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ShieldCheck color={C.gold}/>
          <div><div className="font-bold">Administration FALY MiRay</div><div className="text-[11px]" style={{color:"#aeb7c8"}}>{user.email}</div></div>
        </div>
        <button onClick={()=>signOut(auth)} className="rounded-xl px-3 py-2 flex items-center gap-2 text-xs" style={{background:C.navySoft}}><LogOut size={15}/> Déconnexion</button>
      </div>
    </header>

    <main className="max-w-7xl mx-auto p-4 md:p-6">
      <div className="grid md:grid-cols-4 gap-3">
        {cards.map(([label,value,I])=><div key={label} className="bg-white rounded-2xl p-4 shadow-sm">
          <I color={C.gold}/><div className="text-2xl font-bold mt-2">{value}</div><div className="text-xs" style={{color:C.slate}}>{label}</div>
        </div>)}
      </div>

      {error && <div className="mt-4 p-3 rounded-xl text-xs bg-red-50 text-red-700">{error}</div>}

      <div className="mt-5 grid lg:grid-cols-[230px_1fr] gap-4">
        <aside className="bg-white rounded-2xl p-2 h-fit">
          {Object.entries(defs).map(([key,d])=>{const I=d.icon; const active=tab===key; return <button key={key} onClick={()=>setTab(key)}
            className="w-full rounded-xl p-3 flex items-center gap-2 text-left text-sm"
            style={{background:active?C.navy:"transparent",color:active?C.white:C.navy}}>
            <I size={16} color={active?C.gold:C.slate}/><span className="flex-1">{d.label}</span><span className="text-xs">{data[key].length}</span>
          </button>})}
        </aside>

        <section className="bg-white rounded-2xl p-4 md:p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-4"><Icon color={C.gold}/><h2 className="font-bold">{Def.label}</h2></div>
          <div className="space-y-2">
            {data[tab].length===0 && <div className="py-10 text-center text-sm" style={{color:C.slate}}>Aucune donnée.</div>}
            {data[tab].map(item => <div key={item.id} className="rounded-xl p-3 flex flex-col md:flex-row md:items-center gap-3" style={{border:"1px solid #e5e7eb"}}>
              {item.imageUrl && <img src={item.imageUrl} className="w-16 h-16 rounded-lg object-cover"/>}
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm truncate">{item.name || item.title || item.displayName || item.email || item.id}</div>
                <div className="text-[11px] mt-1" style={{color:C.slate}}>
                  {item.category || item.type || item.city || item.email || "—"}
                </div>
                {item.status && <span className="inline-block mt-2 text-[10px] rounded-full px-2 py-1"
                  style={{background:item.status==="published"?"#dcfce7":item.status==="rejected"?"#fee2e2":"#fef3c7",
                  color:item.status==="published"?"#166534":item.status==="rejected"?"#991b1b":"#92400e"}}>{item.status}</span>}
              </div>
              <div className="flex items-center gap-1">
                {tab!=="users" && item.status!=="published" && <button title="Valider" onClick={()=>approve(item)} className="p-2 rounded-lg bg-green-50"><Check size={16} color="#15803d"/></button>}
                {tab!=="users" && item.status!=="rejected" && <button title="Refuser" onClick={()=>reject(item)} className="p-2 rounded-lg bg-amber-50"><X size={16} color="#a16207"/></button>}
                <button title="Supprimer" onClick={()=>remove(item)} className="p-2 rounded-lg bg-red-50"><Trash2 size={16} color="#b91c1c"/></button>
              </div>
            </div>)}
          </div>
        </section>
      </div>
    </main>
  </div>
}
