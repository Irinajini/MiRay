import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  browserLocalPersistence,
  setPersistence
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { FIREBASE_CONFIG } from './appConfig.js';

export const firebaseReady = Boolean(
  FIREBASE_CONFIG.apiKey &&
  FIREBASE_CONFIG.apiKey.startsWith('AIza') &&
  FIREBASE_CONFIG.projectId === 'faly-miray' &&
  FIREBASE_CONFIG.appId
);

export const app = firebaseReady
  ? (getApps().length ? getApps()[0] : initializeApp(FIREBASE_CONFIG))
  : null;

export const auth = app ? getAuth(app) : null;
export const db = app ? getFirestore(app) : null;
export const firebaseConfigInUse = FIREBASE_CONFIG;

if (auth) {
  setPersistence(auth, browserLocalPersistence).catch(console.warn);
}

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });
