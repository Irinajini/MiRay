import React, { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft, Building2, CalendarDays, ImagePlus, Plus, Save, ShoppingBag,
  Sparkles, Trash2, BriefcaseBusiness, BadgeCheck
} from "lucide-react";
import {
  addDoc, collection, deleteDoc, doc, onSnapshot, query,
  serverTimestamp, updateDoc, where
} from "firebase/firestore";
import { auth, db } from "./firebase.js";
import { uploadImage } from "./services/cloudinary.js";

const C = {
  navy: "#0D1321", navySoft: "#161F33", navyLine: "#232E47",
  gold: "#D4AF37", white: "#FFFFFF", slate: "#6B7280", ivory: "#F7F4EE"
};

function Field({ label, ...props }) {
  return <label className="block">
    <span className="text-xs font-medium" style={{color:C.slate}}>{label}</span>
    <input {...props} className="mt-1 w-full rounded-xl px-3 py-2.5 outline-none text-sm"
      style={{background:C.white,border:"1px solid #e5e7eb",color:C.navy}} />
  </label>;
}

function Textarea({ label, ...props }) {
  return <label className="block">
    <span className="text-xs font-medium" style={{color:C.slate}}>{label}</span>
    <textarea {...props} className="mt-1 w-full rounded-xl px-3 py-2.5 outline-none text-sm min-h-24"
      style={{background:C.white,border:"1px solid #e5e7eb",color:C.navy}} />
  </label>;
}

const forms = {
  page: {
    title: "Ma page MiRay",
    icon: Building2,
    collection: "pages",
    fields: [
      ["name","Nom de l'activité"],
      ["category","Catégorie"],
      ["city","Ville"],
    ]
  },
  product: {
    title: "Nouveau produit",
    icon: ShoppingBag,
    collection: "products",
    fields: [
      ["name","Nom du produit"],
      ["price","Prix (ex. 25 000 Ar)"],
      ["category","Catégorie"],
    ]
  },
  opportunity: {
    title: "Nouvelle opportunité",
    icon: BriefcaseBusiness,
    collection: "opportunities",
    fields: [
      ["title","Titre"],
      ["type","Type (mission, emploi, partenariat...)"],
      ["city","Ville"],
    ]
  },
  event: {
    title: "Nouvel événement",
    icon: CalendarDays,
    collection: "events",
    fields: [
      ["name","Nom de l'événement"],
      ["date","Date"],
      ["city","Ville"],
    ]
  },
};

export default function CreatorStudio({ onBack }) {
  const user = auth.currentUser;
  const [section, setSection] = useState("page");
  const [items, setItems] = useState({pages:[], products:[], opportunities:[], events:[]});
  const [form, setForm] = useState({});
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    if (!user || !db) return;
    const unsubs = ["pages","products","opportunities","events"].map(name => {
      const q = query(collection(db,name), where("ownerId","==",user.uid));
      return onSnapshot(q, snap => {
        setItems(prev => ({...prev, [name]: snap.docs.map(d => ({id:d.id,...d.data()}))}));
      }, err => console.warn(name, err));
    });
    return () => unsubs.forEach(fn => fn());
  }, [user?.uid]);

  const def = forms[section];
  const Icon = def.icon;
  const list = items[def.collection] || [];

  const upload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true); setNotice("");
    try {
      const r = await uploadImage(file);
      setImageUrl(r.url || r.secure_url);
      setNotice("Image envoyée sur Cloudinary.");
    } catch (e) {
      setNotice(e.message || "Échec de l'upload.");
    } finally { setBusy(false); }
  };

  const save = async () => {
    if (!user) return;
    const requiredKey = def.fields[0][0];
    if (!form[requiredKey]?.trim()) {
      setNotice("Complète au moins le premier champ.");
      return;
    }
    setBusy(true); setNotice("");
    try {
      const payload = {
        ...form,
        description,
        imageUrl,
        ownerId: user.uid,
        ownerName: user.displayName || user.email || "Utilisateur MiRay",
        ownerEmail: user.email || "",
        status: section === "page" ? "pending" : "published",
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      await addDoc(collection(db, def.collection), payload);
      setForm({}); setDescription(""); setImageUrl("");
      setNotice(section === "page"
        ? "Page envoyée à l'administration pour validation."
        : "Publication créée.");
    } catch (e) {
      console.error(e);
      setNotice("Impossible d'enregistrer. Vérifie Firestore et ses règles.");
    } finally { setBusy(false); }
  };

  const remove = async (collectionName, id) => {
    if (!confirm("Supprimer cette publication ?")) return;
    await deleteDoc(doc(db, collectionName, id));
  };

  return <div className="min-h-screen" style={{background:C.ivory,color:C.navy,fontFamily:"Poppins, sans-serif"}}>
    <header className="sticky top-0 z-20 px-4 py-3" style={{background:C.navy,color:C.white}}>
      <div className="max-w-6xl mx-auto flex items-center gap-3">
        <button onClick={onBack} className="p-2 rounded-full" style={{background:C.navySoft}}><ArrowLeft size={18}/></button>
        <div>
          <div className="font-bold">Espace activité MiRay</div>
          <div className="text-[11px]" style={{color:"#aeb7c8"}}>Le même compte peut acheter, vendre, publier et chercher des opportunités.</div>
        </div>
      </div>
    </header>

    <main className="max-w-6xl mx-auto p-4 md:p-6">
      <div className="rounded-2xl p-4 mb-5" style={{background:C.navy,color:C.white}}>
        <div className="flex items-center gap-2"><Sparkles color={C.gold}/><b>Votre activité, sans changer de compte</b></div>
        <p className="text-xs mt-2" style={{color:"#b7c0d0"}}>Créez votre page, publiez des produits, événements et opportunités. Vous conservez l'accès normal à toute l'application client.</p>
      </div>

      <div className="grid md:grid-cols-4 gap-2 mb-5">
        {Object.entries(forms).map(([key,f]) => {
          const I = f.icon;
          const active = section===key;
          return <button key={key} onClick={()=>{setSection(key);setForm({});setDescription("");setImageUrl("");setNotice("");}}
            className="rounded-xl p-3 flex items-center gap-2 text-left"
            style={{background:active?C.gold:C.white,color:active?C.navy:C.navy,border:"1px solid #e5e7eb"}}>
            <I size={17}/><span className="text-xs font-semibold">{f.title}</span>
          </button>
        })}
      </div>

      <div className="grid lg:grid-cols-[1fr_1.1fr] gap-5">
        <section className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-4"><Icon color={C.gold}/><h2 className="font-bold">{def.title}</h2></div>
          <div className="space-y-3">
            {def.fields.map(([key,label]) =>
              <Field key={key} label={label} value={form[key]||""}
                onChange={e=>setForm(v=>({...v,[key]:e.target.value}))}/>
            )}
            <Textarea label="Description" value={description} onChange={e=>setDescription(e.target.value)} placeholder="Présentez clairement votre offre..." />
            <label className="block">
              <span className="text-xs font-medium" style={{color:C.slate}}>Image</span>
              <div className="mt-1 rounded-xl p-3 flex items-center justify-between" style={{border:"1px dashed #d1d5db"}}>
                <span className="text-xs" style={{color:C.slate}}>{imageUrl ? "Image prête" : "JPG, PNG ou WEBP — 5 Mo max"}</span>
                <span className="relative rounded-lg px-3 py-2 text-xs font-semibold" style={{background:C.navy,color:C.white}}>
                  <ImagePlus size={14} className="inline mr-1"/> Choisir
                  <input type="file" accept="image/jpeg,image/png,image/webp" onChange={upload} className="absolute inset-0 opacity-0 cursor-pointer"/>
                </span>
              </div>
              {imageUrl && <img src={imageUrl} className="mt-2 w-full h-40 object-cover rounded-xl" />}
            </label>
            <button onClick={save} disabled={busy} className="w-full rounded-xl py-3 font-semibold flex items-center justify-center gap-2"
              style={{background:C.gold,color:C.navy,opacity:busy?.7:1}}>
              <Save size={17}/>{busy?"Enregistrement…":"Enregistrer"}
            </button>
            {notice && <div className="text-xs rounded-lg p-2" style={{background:"#f8fafc",color:C.slate}}>{notice}</div>}
          </div>
        </section>

        <section className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold">Mes publications</h2>
            <span className="text-xs px-2 py-1 rounded-full" style={{background:"#f4f4f5",color:C.slate}}>{list.length}</span>
          </div>
          <div className="space-y-2">
            {list.length===0 && <div className="text-sm py-8 text-center" style={{color:C.slate}}>Aucune publication pour l'instant.</div>}
            {list.map(item => <div key={item.id} className="rounded-xl p-3 flex gap-3" style={{border:"1px solid #e5e7eb"}}>
              {item.imageUrl ? <img src={item.imageUrl} className="w-16 h-16 rounded-lg object-cover"/> :
                <div className="w-16 h-16 rounded-lg grid place-items-center" style={{background:"#f5f5f5"}}><Icon color={C.gold}/></div>}
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm truncate">{item.name || item.title}</div>
                <div className="text-[11px] mt-1" style={{color:C.slate}}>{item.category || item.type || item.city || ""}</div>
                <div className="flex items-center gap-1 mt-2 text-[10px]" style={{color:item.status==="published"?"#15803d":"#a16207"}}>
                  {item.status==="published" && <BadgeCheck size={12}/>}
                  {item.status==="published" ? "Publié" : "En attente de validation"}
                </div>
              </div>
              <button onClick={()=>remove(def.collection,item.id)} className="p-2 self-start"><Trash2 size={15} color="#b91c1c"/></button>
            </div>)}
          </div>
        </section>
      </div>
    </main>
  </div>;
}
