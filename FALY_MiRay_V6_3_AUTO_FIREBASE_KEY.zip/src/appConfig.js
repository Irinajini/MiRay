// FALY MiRay V6.3 — configuration automatique
// La clé API Firebase est injectée automatiquement au build par GitHub Actions.
// Aucun changement manuel du code n'est nécessaire pour changer de clé.

const env = import.meta.env || {};

export const FIREBASE_CONFIG = {
  apiKey: env.VITE_FIREBASE_API_KEY || "",
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || "faly-miray.firebaseapp.com",
  projectId: env.VITE_FIREBASE_PROJECT_ID || "faly-miray",
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || "faly-miray.firebasestorage.app",
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || "952480755434",
  appId: env.VITE_FIREBASE_APP_ID || "1:952480755434:web:374ab34357741b45113193",
  measurementId: env.VITE_FIREBASE_MEASUREMENT_ID || "G-M5L5YXV4KJ",
};

export const CLOUDINARY_CONFIG = {
  cloudName: env.VITE_CLOUDINARY_CLOUD_NAME || "alfrtkxe",
  uploadPreset: env.VITE_CLOUDINARY_UPLOAD_PRESET || "faly_miray_uploads",
  maxFileSizeMb: 5,
  allowedMimeTypes: ["image/jpeg", "image/png", "image/webp"],
};

export const APP_CONFIG = {
  hostingSiteId: "miray",
  projectId: "faly-miray",
  appName: "FALY MiRay",
};
